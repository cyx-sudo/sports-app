"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.default = {
    // use for cookie sign key, should change to your own and keep security
    keys: '1752288351042_6707',
    koa: {
        port: 7001,
    },
    cors: {
        origin: 'http://localhost:5173',
        credentials: true,
    },
};
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiY29uZmlnLmRlZmF1bHQuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi9zcmMvY29uZmlnL2NvbmZpZy5kZWZhdWx0LnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7O0FBRUEsa0JBQWU7SUFDYix1RUFBdUU7SUFDdkUsSUFBSSxFQUFFLG9CQUFvQjtJQUMxQixHQUFHLEVBQUU7UUFDSCxJQUFJLEVBQUUsSUFBSTtLQUNYO0lBQ0QsSUFBSSxFQUFFO1FBQ0osTUFBTSxFQUFFLHVCQUF1QjtRQUMvQixXQUFXLEVBQUUsSUFBSTtLQUNsQjtDQUNjLENBQUMifQ==